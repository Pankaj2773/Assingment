export interface IStudents
{   
    Name: String,
    RollNo : Number,
    Address: String
}