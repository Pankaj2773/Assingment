import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-database',
  templateUrl: './database.component.html',
})
export class DatabaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
